//Numpy array shape [1]
//Min 0.104594007134
//Max 0.104594007134
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b8[1];
#else
output_dense_bias_t b8[1] = {0.1045940071};
#endif

#endif
